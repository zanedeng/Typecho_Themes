window.onload = function(){
    var templateclue = document.getElementById("templateclue");
    if (templateclue == null) {
        window.location.href = "https://www.templateclue.com/"
    };
    templateclue.setAttribute("href", "https://www.templateclue.com/");
    templateclue.setAttribute("ref", "dofollow");
    templateclue.setAttribute("title", "Premium Blogger Templates");
    templateclue.setAttribute("style", "display: inline-block!important; font-size: inherit!important; color: #424243!important; visibility: visible!important; opacity: 1!important;");
    templateclue.innerHTML = "Premium Blogger Templates";
    setInterval(function(){
        if (!$("#templateclue:visible").length) {
            window.location.href = "https://www.templateclue.com/"
        }
    }, 3000)
};

function stripTags(_0xc634x5, _0xc634x6) {
    return _0xc634x5.replace(/<.*?>/ig, "").split(/\s+/).slice(0,_0xc634x6- 1).join(" ");
}

function readmore(id, author, date, title, link) {
    var element = document.getElementById(id)
    var imgElement = "";
    var iframeElement = "";
    var src = "";
    var postImg = "https://1.bp.blogspot.com/-al_KFLCmkqE/WG6Dq6WMb4I/AAAAAAAAA_w/G02ceV-ipSA-I0v3XbOcFq9lji-PknpPgCLcB/s1600/default.jpg";
    var index = -1;
    var imgs = element.getElementsByTagName("img");
    var iframes = element.getElementsByTagName("iframe");
    for (var i=0; i < iframes.length; i++) {
        src = iframes[i].src;
        if (src.indexOf("//www.youtube.com/embed/") !=  -1) {
            index = i;
            break;
        } else if(src.indexOf("//player.vimeo.com/video/") !=  -1) {
            index = i;
            break;
        } else if(src.indexOf("//www.dailymotion.com/embed/video/") !=  -1) {
            index = i;
            break;
        } else if(src.indexOf("//w.soundcloud.com/player/") !=  -1) {
            index = i;
            break;
        }
    }

    if (index !=  -1) {
        iframeElement= "<iframe src=\"" + src + "?vq=medium&rel=0\" frameborder=\"0\" allowfullscreen class=\"viframe\"></iframe>";
        var content = "<div class=\"item\">" 
            + "<div class=\"post-img position-re o-hidden\">" 
            + iframeElement 
            + "</div><div class=\"content\"><span class=\"data\"><a href=\"#0\" class=\"undecro\">"
            + author
            + "</a><a href=\"#0\" class=\"undecro\">"
            + date
            + "</a></span><h5><a href=\""
            + link
            + "\" class=\"undecro\">"
            + title
            + "</a></h5><a href=\""
            + link
            + "\" class=\"more mt-30\"><span>Read More</span></a></div></div>"
    } else if (imgs.length >= 1) {
        imgElement = "<img src='" + imgs[0].src + "' alt='" + title + "' title='" + title + "'>";
        var content = "<div class=\"item\"><div class=\"post-img position-re o-hidden\">"
            + imgElement
            + "</div><div class=\"content\"><span class=\"data\"><a href=\"#0\" class=\"undecro\">"
            + author
            + "</a><a href=\"#0\" class=\"undecro\">"
            + date
            + "</a></span><h5><a href=\""
            + link
            + "\" class=\"undecro\">"
            + title
            + "</a></h5><a href=\""
            + link
            + "\" class=\"more mt-30\"><span>Read More</span></a></div></div>";
    } else {
        var content = "<div class=\"item\"><div class=\"post-img position-re o-hidden\">"
            + postImg
            + "</div><div class=\"content\"><span class=\"data\"><a href=\"#0\" class=\"undecro\">"
            + author
            + "</a><a href=\"#0\" class=\"undecro\">"
            + date
            + "</a></span><h5><a href=\""
            + link
            + "\" class=\"undecro\">"
            + title
            + "</a></h5><a href=\""
            + link
            + "\" class=\"more mt-30\"><span>Read More</span></a></div></div>";
    }
    element.innerHTML = content;
}
    