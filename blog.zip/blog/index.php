<?php
/**
 * 该主题是使用Bootstrap构建的博客，包含作品集、业务、个人单页的多用途模板。模板设计平坦而简单，具有鲜艳的色彩和专门创建的自定义模块，可轻松创建内容。
 * 
 * @package zane-blog
 * @author zane.deng
 * @version 1.0
 * @link zanedeng.github.io
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>


<?php $this->need('footer.php'); ?>